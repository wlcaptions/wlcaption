package com.dyz.persist.util;

/**
 * Created by kevin on 2016/6/21.
 */
public class GlobalData {



}

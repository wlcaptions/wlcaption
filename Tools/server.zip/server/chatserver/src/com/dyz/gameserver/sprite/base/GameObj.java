package com.dyz.gameserver.sprite.base;

/**
 * 服务器中精灵接口
 *
 * @author  daiyongzhi
 * @date 2015年1月30日 下午4:42:46
 * @version V1.0
 */
public interface GameObj {

	public void destroyObj();
}

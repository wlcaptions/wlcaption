package com.context;

public class ConnectAPI {

	public ConnectAPI() {
		// TODO Auto-generated constructor stub
	}

	public static int MicInput_Request = 200;
	public static int MicInput_Response = 201;

	public static int Chat_Login_Request = 202;


}

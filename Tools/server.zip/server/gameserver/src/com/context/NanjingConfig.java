package com.context;

/**
 * Created by Gener on 2017/5/7.
 */
public class NanjingConfig {
    public static int[] ROOMCARD = { 20, 30, 60 };
    public static int[] ROOMCARD_AA = { 6, 10, 20 };
    public static int[] YUANZI_ROOMCARD = { 20, 30, 60 };
    public static int[] YUANZI_ROOMCARD_AA = { 6, 10, 20 };
    public static int HUA_INDEX = 31;
    public static int PAI_COUNT = 42;
    public static int[] ROUND_SET = { 4, 8, 16 };
    public static int[] YUANZI_ROUND_SET = { 4, 8, 16 };
    public static int ROUND_DEFAULT = 8;
    public static int SCORE_DEFAULT = 2000;
    public static int[] ZASHU_SET = { 1, 2 };
    public static int[] PAOFEN_SET = { 5, 10 };
    public static int[] YUANZI_COUNT_SET = { 100, 200, 400 };
    public static int[] YUANZI_RULE_SET = { 1, 2, 3 };
}

package com.dyz.gameserver.msg.response;

import java.io.IOException;

import com.context.ConnectAPI;
import com.dyz.gameserver.commons.message.ServerResponse;

public class ChongzhijiluResponse extends ServerResponse{

	public ChongzhijiluResponse(int status, String str) {
		super(status,ConnectAPI.CHONG_ZHI_JI_LU_RESPONSE);
		if(status>0){
			try {
				output.writeUTF(str);
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				output.close();
			}
		}
	}

}

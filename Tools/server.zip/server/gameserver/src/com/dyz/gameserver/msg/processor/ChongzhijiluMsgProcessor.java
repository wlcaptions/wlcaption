package com.dyz.gameserver.msg.processor;

import com.context.ErrorCode;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dyz.gameserver.commons.message.ClientRequest;
import com.dyz.gameserver.commons.session.GameSession;
import com.dyz.gameserver.msg.processor.common.INotAuthProcessor;
import com.dyz.gameserver.msg.processor.common.MsgProcessor;
import com.dyz.gameserver.msg.response.ErrorResponse;
import com.dyz.gameserver.msg.response.ChongzhijiluResponse;
import com.dyz.myBatis.model.PlayRecord;
import com.dyz.myBatis.services.PlayRecordService;
import com.dyz.persist.util.StringUtil;

/**
 * 获取游戏回放
 * @author luck
 *
 */
public class ChongzhijiluMsgProcessor  extends MsgProcessor implements
INotAuthProcessor{

	@Override
	public void process(GameSession gameSession, ClientRequest request) throws Exception {
		JSONArray  array = new JSONArray();
		/*
			JSONObject json = new JSONObject();
			json.put("id", i);
			json.put("value", 6);
			json.put("count", 6);
			json.put("status", "已支付");
			json.put("time", "2017.06.25 08:12:12");
			array.add(json);
		*/
		gameSession.sendMsg(new ChongzhijiluResponse(1, array.toJSONString()));
	}
	
}

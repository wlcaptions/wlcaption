package com.dyz.gameserver.logic;

/**
 * 
 */
public class AvatarLogic {
}
